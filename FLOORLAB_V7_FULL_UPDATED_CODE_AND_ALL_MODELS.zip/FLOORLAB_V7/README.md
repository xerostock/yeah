# FLOORLAB V7 — ALL FILES, ALL CODE

**This is a newly built HTML/CSS/JavaScript configurator — not the previous V5 or V6 package.**

Start on Windows: double-click `start-local.bat`, then open `http://localhost:8000`.
On Mac/Linux: run `python3 -m http.server 8000` from this folder, then open that address.

All code is inside the full editable `index.html` (~30 KB CSS plus the JavaScript). Three.js libraries are loaded from CDN, so an internet connection is needed. All source GLB assets are bundled in `assets/`.

## V7 confirmed options

- **Grip tape:** 79 SEK each, matte black demonstration shaft and no blade; sticky white, sticky grey, black, baby blue, pink and black magic. No custom text or name label.
- **Floorball balls:** CRATER glowing in the dark, white, orange, dark pink, dark yellow, custom multicolour (four editable colours; quarters, rings or swirl). Standard daylight scene — no night mode.
- **Ball pack prices:** 1 = 19 SEK; 10 = 99 SEK; 25 = 199 SEK; 50 = 329 SEK; 100 = 499 SEK; 200 = 799 SEK; 250 = 949 SEK.
- **Headbands:** thin (49 SEK) and thick (69 SEK) fabric bands displayed on the user-provided head mesh, skin-tone material, adjustable colors and optional subtle front text. These are prototype prices.
- Demo cart, screenshot capture, rotate and zoom, responsive page.

## Notes

This is an interactive demonstration, not a ready-to-sell ecommerce site. No payments, inventory, fulfilment, physical manufacturing or user accounts are connected. Glow and mixed-colour printing are visual approximations. The model creator's commercial licenses/permissions should be confirmed before use in a live store. The head scan had no lifelike texture, so skin color is approximated with a material. Textures, fit, and materials should be tested on your own device before selling.

## Cache

The header visibly reads **V7 · UPDATED 24 OCT**. If it doesn't, you opened an old version: extract this ZIP into a new folder, open that folder, and run its `start-local.bat`.
